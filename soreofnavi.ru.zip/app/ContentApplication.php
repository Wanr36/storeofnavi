<?php

namespace Storeofnavi;

use Illuminate\Database\Eloquent\Model;

class ContentApplication extends Model
{
    protected $table='contentApplication';
}
