<?php
namespace Storeofnavi;
use Illuminate\Database\Eloquent\Model;
class MyProfileModel extends Model
{
    //users - это название таблицы в базе данных.
     protected $table='users';
}