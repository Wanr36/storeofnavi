$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
var messege = {
    Error : function(){
        var header = "<i class='fa fa-exclamation'></i> Ошибка",
            body = "Ошибка на стороне сервера! Перезагрузите страницу.";
        $(".modal-title-msg").html(header);
        $(".modal-body-msg p").html(body);
        $("#msg").modal("show");
    },
    Success : function(){}
};
function MSG(head,msg){
    this.msg = msg;
    this.head=head;
}
MSG.prototype.talk = function(){
    var header="<i class='fa fa-comment-o'></i> "+this.head,
        body=this.msg;
    $("#myModal .modal-title").html(header);
    $("#myModal .modal-body p").html(body);
    $("#myModal").modal("show");
}
$(function(){
    $(".application-scr").css("height", "300px");
    $(".dostal").css("height", "55%");
    $('[data-toggle="tooltip"]').tooltip();
    //Logout
    $(".exit_admin").on("click", function(){
        $("#myModal").modal("show");
    });
    //EndLogout

    $(".add_new_application").on("click", function(){
        //Берем id
        location.href="application";
    });
    //Страница дисциплина
    var files;
    $('.img').change(function(){
        files = this.files;
    });
    $(".add_course").on("submit", function(e){
        e.preventDefault();
        var data = new FormData(),
            form = $(this),
            $img = $(".img"),
            url=$(".add_course").attr("action"),
            text = form.serialize();
        data.append("nameDisciplines", $(".nameDisciplines").val());
        data.append("actionDisciplines", $(".actionDisciplines").val());
        data.append("shortDiscipline", $(".shortDiscipline").val());
        data.append("discription", $(".discription").val());
        data.append("discriptionForImg", $(".discriptionForImg").val());
        data.append('img', $img.prop('files')[0]);
        $.ajax({
            url: url,
            type: 'POST',
            data: data,
            cache: false,
            dataType: 'JSON',
            processData: false,
            contentType: false
        }).done(function(data){
            $msg =new MSG("Операция прошла успешно", data['msg']);
            $msg.talk();
            var btn="<a href='#"+$(".actionDisciplines").val()+"' class='btn btn-default cource_btn'>"+$(".shortDiscipline").val()+"</a>";
            $(".group_cource").find(".btn_new_course").before(btn);
            $(".header-img").attr('src', data['srcImg']);
        }).fail(function(){
            $msg =new MSG("Ошибка на стороне сервера", "Перезагрузите страницу!");
            $msg.talk();
        });
    });
    $(".cource_btn").on("click", function(){
        $(".group_cource").find(".active").removeClass("active");
        $(this).addClass('active');
        var data = $(this).attr("href").substr(1);

        $.ajax({
            type:"GET",
            dataType:"JSON",
            cache: false,
            url:"/adminzone/select_course",
            data:"pole="+data,
            processData: false,
            contentType: false
        }).done(function(data){
            //console.log(data);
            var disciplines = data['disciplines'][0],
                application = data['application'],
                count_application = application.length;
            console.log(disciplines, application, count_application);

            $(".nameDisciplines").val(disciplines['nameDisciplines']);
            $(".img-text-h3").html(disciplines['nameDisciplines']);
            $(".actionDisciplines").val(disciplines['actionDisciplines']);
            $(".shortDiscipline").val(disciplines['shortDiscipline']);
            $(".discription").val(disciplines['discription']);
            $(".discriptionForImg").val(disciplines['discriptionForImg']);
            $(".img-text-p").html(disciplines['discriptionForImg']);
            $(".delite_corse").removeClass('disabled');
            $(".add_course").addClass("update_course").removeClass("add_course");
            $(".header-img").attr('src', disciplines['img']).height(450).width('80%');
            $.each(application, function(i,e){
                console.log(i);
                if( $.isNumeric(i) ){
                    var titleApplication = application[i]['titleApplication'],
                        id = application[i]['id'];
                    if(i == 0){
                        $(".application-scr").append('<option selected="selected" class="'+id+' aplication-selected">'+titleApplication+'</option>');
                        $(".text-size").html(titleApplication);
                        if(application[i]['priceApplication'] == 0){
                            $(".summa em").html("Бесплатно");
                        }else{
                            $(".summa em").html(application[i]['priceApplication'] + " р.");
                        }
                        $(".dostal").attr('src', application[i]['imgApplication']);
                    }else{
                        $(".application-scr").append('<option class="'+id+' aplication-selected">'+titleApplication+'</option>');
                    }
                }
            });
            $(".aplication-selected").on("click",function(){
                console.log($(this));
            });
            $(".aplication-selected").on("dblclick", function(){
                //Берем id
                var id = $(this).attr('class').split(' ')[0];
                location.href="application/"+id;
            });

        }).fail(function(){
            $msg =new MSG("Ошибка на стороне сервера", "Перезагрузите страницу!");
            $msg.talk();
        });
    });
    $(".btn_new_course").on("click", function(){
        $(".group_cource").find(".active").removeClass("active");
        $(this).addClass('active');
        $(".update_course").addClass("add_course").removeClass("update_course");
        $(".delite_corse").addClass('disabled');
        $(".header-img").attr('src', '/img/slider.png');
    });
    $(".nameDisciplines").change(function(){
        $(".img-text-h3").html($(".nameDisciplines").val());
    });
    $(".discriptionForImg").change(function(){
        $(".img-text-p").html($(".discriptionForImg").val());
    });
    $('.discriptionForImg').keydown(function(){
        $('.img-text-p').html($('.discriptionForImg').val());
    });
    $('.nameDisciplines').keydown(function(){
        $('.img-text-h3').html($('.nameDisciplines').val());
    });
       //$('.img-text-p').val($('.discriptionForImg').val());

    //дисциплинаEnd
    //Страница отзывы
    //$('table.table-reviews').columnFilters({alternateRowClassNames:['rowa','rowb'], excludeColumns:[2,3]});
    //End отзывы
    //Страница Пользователи
    /*$('.table-users').tableSearch({
        searchText:'Поиск по таблице: ',
        searchPlaceHolder:'Ключевое слово'
    });
    $('.buy-table').tableSearch({
        searchText:'Поиск по таблице: ',
        searchPlaceHolder:'Ключевое слово'
    });*/
    //
}());

