<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="RU-ru"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang="RU-ru"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang="RU-ru"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="RU-ru"> <!--<![endif]-->
    <head>
        <?php echo $__env->yieldContent('css'); ?>
    </head>
    
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <div class="head_photo"></div>
        <div class="container header-container">
          <div class="row">
            <?php echo $__env->yieldContent('header'); ?>
            <div class="col-xs-12 col-sm-11 col-md-11 col-lg-11 col-sm-offset-1">
              <div class="application">
                  <div class="row">
                      <div class="col-xs-12">
                          <h2 class="pull-left application-h2">КОСОУГОЛЬНЫЕ СЕФРИЧЕСКИЕ ТРЕУГОЛЬНИКИ</h2>
                      </div>
                      <img src="img/wave.png" class="application-wave" alt="Волна">
                  </div>
                  <div class="row" >
                      <div class="col-xs-12" style="/*background: white; height: 200px;*/ ">
                          <div class="col-xs-3 appInsertData">
                            <div class="col-sm-12 insertHeader">
                              <h5>ВВЕДИ ДАННЫЕ</h5>
                            </div>
                            <form class="form-horizontal" role="form">
                            
                              <div class="form-group">
                                <label class="col-sm-6 control-label appInput appKnow">Известно:</label>
                                <div class="col-sm-1 appInput"></div>
                                <div class="col-sm-4 appInput">
                                  <select id="input1" class="form-control">
                                    <option>ABC</option>
                                    <option>1</option>
                                    <option>2</option>
                                  </select>
                                </div>
                              </div>
                              <div class="form-group">
                                <label for="input2" class=" col-sm-2 control-label appInput">&nbsp;&nbsp;&nbsp;A =</label>
                                <div class="col-sm-4 appInput">
                                  <input type="text" class="form-control" id="input2">
                                </div>
                                <label for="input2" class="col-sm-1 control-label appInput">&deg;&nbsp;&nbsp;&nbsp;</label>
                                <div class="col-sm-4 appInput">
                                  <input type="text" class="form-control" id="input3">
                                </div>
                                <label for="input3" class="col-sm-1 control-label appInput">&prime;&nbsp;&nbsp;&nbsp;</label>
                              </div>
                              <div class="form-group">
                                <label for="input4" class=" col-sm-2 control-label appInput">&nbsp;&nbsp;&nbsp;B =</label>
                                <div class="col-sm-4 appInput">
                                  <input type="text" class="form-control" id="input4">
                                </div>
                                <label for="input4" class="col-sm-1 control-label appInput">&deg;&nbsp;&nbsp;&nbsp;</label>
                                <div class="col-sm-4 appInput">
                                  <input type="text" class="form-control" id="input5">
                                </div>
                                <label for="input5" class="col-sm-1 control-label appInput">&prime;&nbsp;&nbsp;&nbsp;</label>
                              </div>
                              <div class="form-group">
                                <label for="input6" class=" col-sm-2 control-label appInput">&nbsp;&nbsp;&nbsp;C =</label>
                                <div class="col-sm-4 appInput">
                                  <input type="text" class="form-control" id="input6">
                                </div>
                                <label for="input6" class="col-sm-1 control-label appInput">&deg;&nbsp;&nbsp;&nbsp;</label>
                                <div class="col-sm-4 appInput">
                                  <input type="text" class="form-control" id="input7">
                                </div>
                                <label for="input7" class="col-sm-1 control-label appInput">&prime;&nbsp;&nbsp;&nbsp;</label>
                              </div>
                              <div class="col-sm-12 insertFooter">
                                <div class="col-sm-6 col-sm-offset-6 btn-accept">
                                  <button type="submit" class="btn btn-default ">РЕШИТЬ</button>
                                </div>
                              </div>
                              <div class="col-sm-6 price-badge">
                                <em class="pull-right">Бесплатно</em>
                              </div>
                              <div class="col-sm-12 clear-form">
                                <a href="#">ОЧИСТИТЬ ФОРМУ</a>
                              </div>
                            </form>
                            <div class="row">
                            <div class="col-sm-12 show-example">
                              <a href="#"><span class="glyphicon glyphicon-th-list"></span> ПОСМОТРЕТЬ ПРИМЕР РЕШЕНИЯ</a>
                            </div>
                              
                            </div>
                          </div>
                          <div class="col-xs-7 col-xs-offset-1 app-danger">
                            <b>Предупреждение:</b> Данным приложением может пользоваться только <a href="#">зарегистрированный пользователь</a>, пройдите <a href="#">авторизацию</a>!
                          </div>
                          <div class="col-xs-9 app-about">
                            Для нахождения неизвестных элементов косоугольного сфеического треугольника выберите из выпадающего списка известные Вам 3 элемента. Напоминаем что заглавные буквы A, B, C - углы сферического треугольника, а строчные a, b, с - стороны треугольника. Затем введите значения выбранных элементов в соответствующие поля. В первое поле каждого элемента вводятся градусы в пределах от 0° до 179°, а во второе минуты от 00.0` до 59.9`. Приложение рассчитано для решения сферического треугольника в котором элементы лежат в пределах от 0° до 180° (треугольник Эйлера). 
                            <p><br><br>Если в выпадающем списке нет подходящих для вас 3-х известных элементов, тогда отправьте нам на <a href="#">почту</a> условия вашей задачи и мы посмотрим чем можем Вам помочь.</p>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="commentaries">
                  <div class="row">
                      <div class="col-xs-12">
                          <h2 class="pull-left application-h2">КОММЕНТАРИИ</h2>
                      </div>
                      <img src="img/wave.png" class="application-wave" alt="Волна">
                  </div>
                  <div class="row" >
                      <div class="col-xs-12" >
                          <div class="col-xs-3 add-comm">
                            Ваши комментарии помогают нам сделать наш сервис еще лучше, более удобным, эффективным и полезным.<br><br>
                            Возможно, ваши отзывы будут полезными и другим пользователям.<br><br>
                            Пожалуйста, поделитесь своими эмоциями от использования этого приложения!<br><br>
                            <button class="btn btn-info add-com-btn">ОСТАВИТЬ КОММЕНТАРИЙ</button>
                          </div>
                          <div class="col-xs-6">
                              <div class="col-xs-12 user-comment" >
                                Изначально я не до конца доверял этому сайту, т.к. тематика, все-таки, весьма специфична и ошибиться в расчетах достаточно легко. Но знаете, результат меня очень обрадовал! Павел большой молодец! эти приложения реально помогают в учебе!
                                <div class="col-xs-7 user-info">
                                  <div class="col-xs-4 user-avatar">
                                    
                                  </div>
                                  <div class="col-xs-8 user-name-date">
                                    <span class="name">Константин<br>Константинопольский </span> <br>
                                    <span class="date">28 августа 2016г.</span>
                                  </div>
                                </div>
                              </div>
                              <div class="col-xs-12 user-comment" >
                                Изначально я не до конца доверял этому сайту, т.к. тематика, все-таки, весьма специфична и ошибиться в расчетах достаточно легко. Но знаете, результат меня очень обрадовал! Павел большой молодец! эти приложения реально помогают в учебе!
                                <div class="col-xs-7 user-info">
                                  <div class="col-xs-4 user-avatar">
                                    
                                  </div>
                                  <div class="col-xs-8 user-name-date">
                                    <span class="name">Константин<br>Константинопольский </span> <br>
                                    <span class="date">28 августа 2016г.</span>
                                  </div>
                                </div>
                              </div>
                              <div class="col-xs-12 user-comment" >
                                Изначально я не до конца доверял этому сайту, т.к. тематика, все-таки, весьма специфична и ошибиться в расчетах достаточно легко. Но знаете, результат меня очень обрадовал! Павел большой молодец! эти приложения реально помогают в учебе!
                                <div class="col-xs-7 user-info">
                                  <div class="col-xs-4 user-avatar">
                                    
                                  </div>
                                  <div class="col-xs-8 user-name-date">
                                    <span class="name">Константин<br>Константинопольский </span> <br>
                                    <span class="date">28 августа 2016г.</span>
                                  </div>
                                </div>
                              </div>
                          </div>
                          <div class="col-xs-3 banner" style="background: green;">
                            <div>
                                <div class="image-caption">
                                    <h3 class="banner-text-h3 pull-right"><em>Решим мореходную астрономию</em></h3>
                                    <br>
                                    <h2 class="banner-text-h2 pull-right">В 1 КЛИК</h2>
                                    <button class="btn btn-danger banner-btn pull-right"><em>решить</em></button>
                                </div>
                                <img class="banner-img" src="img/banner.png" alt="">
                            </div>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
            
          </div>
        </div>
          <div class="row sale-block">
            <div class="container">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3 col-lg-offset-1">
                    <p style="text-align: center;"><button class="btn btn-danger sale-block-btn">ПОПРОБУЙ БЕСПЛАТНО!</button></p>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-7 col-lg-offset-1">
                    <p align="center" class="sale-block-text">Остались сомнения насчет нашего сервиса? Попробуй <span class="color-red">бесплатные приложения</span>!</p>
                </div>
                
            </div>
          </div>
        <?php echo $__env->yieldContent('footer'); ?>

        <?php echo $__env->yieldContent('js'); ?>
    </body>
</html>
