<footer>
  <div class="container">
      <div class="row footer footer-info-nav-desk">
            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 ">
              <p class="footer-img"><img src="img/logo3.png" class="" alt=""></p>
              <p class="footer-text" align="center">2010 — 2016 © «Store of Navi»</p>
              <p class="footer-text" align="center">Качественная моментальная помощь в решении: задач, лабораторных работ, курсовых для курсантов, судоводителей Морского Государственного Университета (МГУ) им. адмирала Г.И. Невельского</p>
            </div>
            <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
                <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                  
                </div>
                <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                  <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                    <dl>
                      <dt class="footer-text-dt">ИНФОРМАЦИЯ</dt>
                      <dd>
                        <ul class="list-unstyled footer-text-ul">
                          <li><a href="#">Приложения</a></li>
                          <li><a href="#">О проекте</a></li>
                          <li><a href="#">Частые вопросы</a></li>
                          <li><a href="#">Контакты</a></li>
                          <br>
                          <li><a href="#">Пользовательское соглашение</a></li>
                        </ul>
                      </dd>
                    </dl>
                  </div>
                  <div class="col-xs-6 col-sm-6 col-md-6 col-lg-5 col-lg-offset-1">
                    <dl>
                      <dt class="footer-text-dt">МОЙ АККАУНТ</dt>
                      <dd>
                        <ul class="list-unstyled footer-text-ul">
                          <li><a href="#">Профиль</a></li>
                          <li><a href="#">Мои покупки</a></li>
                          <li><a href="#">Как польщоваться сайтом</a></li>
                          <br>
                          <li><a href="#">Выйти</a></li>
                        </ul>
                      </dd>
                    </dl>
                  </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="footer-border"></div>
                    <div align="right" class="footer-dev">
                      <a href="#"><img src="img/design.png" alt=""></a>
                      <a href="#"><img src="img/developer.png" alt=""></a>
                    </div>
                    
                </div>
            </div>
      </div>
      <div class="row footer footer-info-nav-mob">
            
            <div class="col-xs-12 col-sm-9 col-md-9 col-lg-9 ">
              <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                <dl>
                  <dt class="footer-text-dt">ИНФОРМАЦИЯ</dt>
                  <dd>
                    <ul class="list-unstyled footer-text-ul">
                      <li><a href="#">Приложения</a></li>
                      <li><a href="#">О проекте</a></li>
                      <li><a href="#">Частые вопросы</a></li>
                      <li><a href="#">Контакты</a></li>
                      <br>
                      <li><a href="#">Пользовательское соглашение</a></li>
                    </ul>
                  </dd>
                </dl>
              </div>
              <div class="col-xs-6 col-sm-6 col-md-6 col-lg-5 col-lg-offset-1">
                <dl>
                  <dt class="footer-text-dt">МОЙ АККАУНТ</dt>
                  <dd>
                    <ul class="list-unstyled footer-text-ul">
                      <li><a href="#">Профиль</a></li>
                      <li><a href="#">Мои покупки</a></li>
                      <li><a href="#">Как польщоваться сайтом</a></li>
                      <br>
                      <li><a href="#">Выйти</a></li>
                    </ul>
                  </dd>
                </dl>
              </div>
            </div>
            <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 footer-info-nav-mob">
              <p class="footer-img"><img src="img/logo3.png" class="" alt=""></p>
              <p class="footer-text" align="center">2010 — 2016 © «Store of Navi»</p>
              <p class="footer-text" align="center">Качественная моментальная помощь в решении: задач, лабораторных работ, курсовых для курсантов, судоводителей Морского Государственного Университета (МГУ) им. адмирала Г.И. Невельского</p>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="footer-border"></div>
                <div align="right" class="footer-dev">
                  <a href="#"><img src="img/design.png" alt=""></a>
                  <a href="#"><img src="img/developer.png" alt=""></a>
                </div>
                
            </div>
      </div>
  </div>
</footer>