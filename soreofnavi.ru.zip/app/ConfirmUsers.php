<?php

namespace Storeofnavi;

use Illuminate\Database\Eloquent\Model;

class ConfirmUsers extends Model
{
    protected $table = 'confirm_users';
}
