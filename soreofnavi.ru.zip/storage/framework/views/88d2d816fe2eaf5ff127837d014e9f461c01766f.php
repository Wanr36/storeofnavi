<?php $__env->startSection('header'); ?>
  <div class="col-xs-12 col-sm-11 col-md-11 col-lg-11 col-sm-offset-1">
  <div class="header-box">
    <div class="row">
        <div class="col-xs-3 col-sm-3 col-md-3 col-lg-2">
            <div class="header-logo">
                <img class="header-logo" src="img/logo.png" alt="Логотип store of navi">
            </div>
        </div>
        <div class="col-xs-9 col-sm-4 col-md-5 col-lg-7 header-nav">
            <div>
              <ul class="nav nav-pills menu-str">
                <li role="presentation" class="nav-li"><a href="application">ПРИЛОЖЕНИЯ</a></li>
                <li role="presentation" class="nav-li"><a href="about-us">О ПРОЕКТЕ</a></li>
                <li role="presentation" class="nav-li"><a href="question">ВОПРОС-ОТВЕТ</a></li>
                <li role="presentation" class="nav-li"><a href="contact">КОНТАКТЫ</a></li>
              </ul>
              <ul class="nav nav-pills menu-burger pull-right">
                <li class="dropdown">
                  <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                    МЕНЮ <span class="caret"></span>
                  </a>
                  <ul class="dropdown-menu">
                    <li role="presentation" class="nav-li visible-xs"><a href="#" data-toggle="modal" data-target="#authregModal">МОЙ АККАУНТ</a></li>
                    <li role="presentation" class="nav-li visible-xs on-btn-search"><a href="#">ПОИСК</a></li>
                    <li role="presentation" class="nav-li"><a href="application">ПРИЛОЖЕНИЯ</a></li>
                    <li role="presentation" class="nav-li"><a href="about-us">О ПРОЕКТЕ</a></li>
                    <li role="presentation" class="nav-li"><a href="question">ВОПРОС-ОТВЕТ</a></li>
                    <li role="presentation" class="nav-li"><a href="contact">КОНТАКТЫ</a></li>
                  </ul>
                </li>
              </ul>
            </div>
        </div>
        <div class="col-sm-5 col-md-4 col-lg-3 menu-navmenu hidden-xs">
            <div class="row">
                <div class="col-sm-1">
                    <i class="glyphicon glyphicon-user menu-user-icon"></i>
                </div>
                <div class="col-sm-8" style="margin-top: 15px">
                    <div><!-- <div class="obertka"> -->
                        <a href="#" data-toggle="modal" data-target="#authregModal"><i class="glyphicon glyphicon-user menu-user-icon2"></i>
                        <span class="menu-user-name">МОЙ ПРОФИЛЬ</span></a>
                    </div>
                </div>
                <i class="glyphicon glyphicon-search menu-search-icon on-btn-search" ></i>
                <div  class="col-sm-1 menu-search-border">
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="col-sm-5 col-sm-offset-7 col-md-4 col-md-offset-8 col-lg-3 col-lg-offset-9 search-input hide">
    <div class="search-input-in">
      <div class="col-xs-12" >
        <div class="input-group">
          <span class="input-group-btn">
            <a href="#" class="glyphicon glyphicon-search" ></a>
          </span>
          <input type="text" class="form-control" placeholder="Поиск..." >
        </div><!-- /input-group -->
      </div>
    </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>