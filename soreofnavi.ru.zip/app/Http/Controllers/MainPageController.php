<?php
	namespace Storeofnavi\Http\Controllers;
	use Storeofnavi\Http\Controllers\Controller;
	use Illuminate\Http\Request;
	class MainPageController extends Controller{
		function Index(){
			$feedback = DB::table('reviews')->where("email", $email)->first();
			return view('main',['feedback'=>$feedback]);
		}
	}

?>