<?php

namespace Storeofnavi;

use Illuminate\Database\Eloquent\Model;

class Rewiews extends Model
{
    protected $table='rewiews';
}
